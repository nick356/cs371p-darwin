var searchData=
[
  ['callprint',['callprint',['../classCreature.html#a94b0ebbaee865af531822c050a5d5aae',1,'Creature']]],
  ['changeface',['changeFace',['../classCreature.html#a83901ae63cc9b522ea9f8bd805e5a09d',1,'Creature']]],
  ['creature',['Creature',['../classCreature.html',1,'Creature'],['../classCreature.html#a8a93572a29d9c200f554269b26e5d483',1,'Creature::Creature()']]]
];
