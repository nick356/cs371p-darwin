var searchData=
[
  ['whtcreat',['whtCreat',['../classCreature.html#ab7d0e53d0b5e800776219af7a4ff0f2c',1,'Creature']]],
  ['whtrn',['whtrn',['../classCreature.html#a06eeb557005cb19e744dd6b3703fd474',1,'Creature']]],
  ['world',['World',['../classWorld.html#a60d79f6a9a3eb6bee44e9f26da148fd4',1,'World']]]
];
