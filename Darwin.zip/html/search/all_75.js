var searchData=
[
  ['updat',['updat',['../classCreature.html#aa488ca47c45c5e12ede997996c892b17',1,'Creature']]]
];
