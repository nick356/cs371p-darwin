var searchData=
[
  ['getcreatu',['getCreatu',['../classWorld.html#af5267ea1379d65641a78929b8f4afab6',1,'World']]],
  ['getname',['getName',['../classWorld.html#a77f98b21f37f128e70160dfbb5c54b64',1,'World']]]
];
