var searchData=
[
  ['incturn',['incturn',['../classCreature.html#a2f9affa2767538c4ced31a37458a013e',1,'Creature']]],
  ['infected',['infected',['../classCreature.html#aa14ed5e2c75a73ca06846b07e9dafbae',1,'Creature']]],
  ['instret',['instret',['../classSpecies.html#a2d600658d80533089953e6bc358bc964',1,'Species']]],
  ['instructjump',['instructjump',['../classSpecies.html#ae2552212a72dcc1a3834f73d836e79ba',1,'Species']]]
];
