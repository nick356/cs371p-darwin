var searchData=
[
  ['map',['map',['../classDarwin.html#af3863008f02c19c7d4a116fff7321845',1,'Darwin']]],
  ['move',['move',['../classSpecies.html#a1b53fab7cf5e0a1ca1eff75a03c4ffea',1,'Species']]]
];
