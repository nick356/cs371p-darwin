var searchData=
[
  ['north',['NORTH',['../RunDarwin_8c_09_09.html#a1711232abf72723b5216c206e6bbb175',1,'RunDarwin.c++']]]
];
