var searchData=
[
  ['setcreat',['setCreat',['../classWorld.html#a0da14d42cb6d0b040f912b5198ad5501',1,'World']]],
  ['species',['Species',['../classSpecies.html#a40f4d99a523fee3f1969156f6a48ac54',1,'Species']]]
];
