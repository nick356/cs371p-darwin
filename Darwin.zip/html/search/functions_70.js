var searchData=
[
  ['printit',['printit',['../classSpecies.html#aac0b2037b164c006c7202d0464f95a79',1,'Species']]],
  ['prognum',['prognum',['../classCreature.html#a02e903625776ece06a24f8aa594eba26',1,'Creature']]],
  ['pronum',['pronum',['../classCreature.html#aaeb41346e479ac400dbed0a3c327ab72',1,'Creature']]]
];
